^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package dummy_sensors
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.8.4 (2019-11-19)
------------------

0.8.3 (2019-11-11)
------------------

0.8.2 (2019-11-08)
------------------

0.8.1 (2019-10-23)
------------------

0.8.0 (2019-09-26)
------------------

0.7.6 (2019-05-30)
------------------
* Fix memory leak in the dummy robot examples. (`#361 <https://github.com/ros2/demos/issues/361>`_)
* Contributors: Chris Lalancette

0.7.5 (2019-05-29)
------------------

0.7.4 (2019-05-20)
------------------

0.7.3 (2019-05-10)
------------------

0.7.2 (2019-05-08)
------------------
* changes to avoid deprecated API's (`#332 <https://github.com/ros2/demos/issues/332>`_)
* Corrected publish calls with shared_ptr signature (`#327 <https://github.com/ros2/demos/issues/327>`_)
* Contributors: William Woodall, ivanpauno

0.7.1 (2019-04-26)
------------------

0.7.0 (2019-04-14)
------------------

0.6.2 (2019-01-15)
------------------

0.6.1 (2018-12-13)
------------------

0.6.0 (2018-12-07)
------------------
* Added semicolons to all RCLCPP and RCUTILS macros. (`#278 <https://github.com/ros2/demos/issues/278>`_)
* Contributors: Chris Lalancette

0.5.1 (2018-06-28)
------------------

0.5.0 (2018-06-27)
------------------
