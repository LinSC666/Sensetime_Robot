Adapted from `~/ros2_overlay_ws/src/examples/rclcpp/minimal_service`.

