// adapted from https://raw.githubusercontent.com/ros2/demos/master/demo_nodes_cpp/src/topics/listener.cpp

#include <cstdio>
#include <memory>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "diff_drive_robot.hpp"

int main(int argc, char * argv[])
{
  // Force flush of the stdout buffer.
  setvbuf(stdout, NULL, _IONBF, BUFSIZ);


  // Initialize ROS2 first, this should be called once per process.
  rclcpp::init(argc, argv);

  // Create a node.
  std::shared_ptr<rclcpp::Node> node_ = rclcpp::Node::make_shared(
                                                   "diff_drive_node");

  // create the robot, give the node to it
  std::unique_ptr<diff_drive_robot::DiffDriveRobot> robot_ = 
                  std::make_unique<diff_drive_robot::DiffDriveRobot>(node_);


  // spin will block until work comes in, execute work as it becomes
  // available, and keep blocking.  It will only be interrupted by Ctrl-C.
  rclcpp::spin(node_);
  rclcpp::shutdown();
  return 0;
}
