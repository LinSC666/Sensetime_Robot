// adapted from https://raw.githubusercontent.com/ros-planning/navigation2/master/nav2_robot/include/nav2_robot/robot.hpp

#ifndef DIFF_DRIVE_ROBOT_HPP
#define DIFF_DRIVE_ROBOT_HPP

#include <string>
#include "rclcpp/rclcpp.hpp"
#include "urdf/model.h"
#include "nav_msgs/msg/odometry.hpp"

namespace diff_drive_robot
{

class DiffDriveRobot
{
public:
  explicit DiffDriveRobot(rclcpp::Node::SharedPtr & _node);
  DiffDriveRobot() = delete;

  bool getOdometry(nav_msgs::msg::Odometry::SharedPtr & robot_odom);
  std::string getName();

protected:
  // The ROS node to use to create publishers and subscribers
  rclcpp::Node::SharedPtr node_;

  // Subscriber
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;

  // Subscription callbacks
  void onOdomReceived(const nav_msgs::msg::Odometry::SharedPtr msg);

  // The odometry as received from the Odometry subscription
  nav_msgs::msg::Odometry::SharedPtr current_odom_;

  // Whether the subscriptions have been received
  bool initial_odom_received_;

  // Information about the robot is contained in the URDF file
  std::string urdf_file_;
  urdf::Model model_;
};

}  // namespace

#endif
