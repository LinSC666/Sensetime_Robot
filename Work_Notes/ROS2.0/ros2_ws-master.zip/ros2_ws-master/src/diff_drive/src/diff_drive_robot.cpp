// Adapted from https://github.com/ros-planning/navigation2/blob/master/nav2_robot/src/robot.cpp

#include "diff_drive_robot.hpp"

#include <string>
#include <exception>
#include "urdf/model.h"

namespace diff_drive_robot
{

DiffDriveRobot::DiffDriveRobot(rclcpp::Node::SharedPtr & node) : node_(node), initial_odom_received_(false)
{
  odom_sub_ = node_->create_subscription<nav_msgs::msg::Odometry>(
    "/demo/odom_demo", std::bind(&DiffDriveRobot::onOdomReceived, this, std::placeholders::_1));
  std::cout << "DiffDriveRobot::DiffDriveRobot.a\n";
}

void
DiffDriveRobot::onOdomReceived(const nav_msgs::msg::Odometry::SharedPtr msg)
{
  current_odom_ = msg;
  if (!initial_odom_received_) {
    std::cout << "DiffDriveRobot::onOdomReceived.a\n";
    RCLCPP_INFO(node_->get_logger(), "onOdomReceived");
    initial_odom_received_ = true;
  }
//  RCLCPP_INFO(node_->get_logger(), "onOdomReceived more");
  std::cout << "DiffDriveRobot::onOdomReceived.b x: " << msg->pose.pose.position.x << " y: " << msg->pose.pose.position.y << " z: " << msg->pose.pose.position.z << "\n";
}

bool
DiffDriveRobot::getOdometry(nav_msgs::msg::Odometry::SharedPtr & robot_odom)
{
  if (!initial_odom_received_) {
    RCLCPP_DEBUG(node_->get_logger(),
      "DiffDriveRobot: Can't return current velocity: Initial odometry not yet received.");
    return false;
  }

  robot_odom = current_odom_;
  return true;
}

std::string
DiffDriveRobot::getName()
{
  return "diff_drive_robot";
}

}  // namespace

